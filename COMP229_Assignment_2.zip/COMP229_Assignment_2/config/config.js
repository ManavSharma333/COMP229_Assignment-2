// Alert: For production environment never expose your connection string AND secret keys.
module.exports = {
    "ATLASDB" : "mongodb+srv://manav_comp229_assignment-2:27Manav27@cluster0.aspenhw.mongodb.net/DressStore?retryWrites=true&w=majority"
}